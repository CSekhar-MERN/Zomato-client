import React from 'react';
import './App.css';
// import Home from './Components/Home';
// import CarouselPage from './Components/Details';
// import Filter from './Components/Filter';
import Router from './Components/Router';

function App() {
  
  return (
    <div>
       {/* <Home /> */}
      {/* <Filter /> */}
      <Router />
      {/* <CarouselPage /> */}
    </div>
  );
}

export default App;
