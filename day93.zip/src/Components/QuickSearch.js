import React from "react";

function QuickSearch(){
    return(
        <div>
            <div className="container-fluid feature ">
                    <h1>Quick searches</h1>
                    <p>Discover restaurants by type of meal</p>
                </div>
        </div>
    )
}
export default QuickSearch;